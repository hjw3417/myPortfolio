function test(){
	alert("thymeleaf 테스트입니다");
	
}
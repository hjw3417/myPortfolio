package dc.human.whosthebest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhosthebestApplicationTests {

	@Test
	void contextLoads() {
	}

}
